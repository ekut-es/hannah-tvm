// tvm target: c -keys=cpu -model=host
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_nn_relu(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  void* arg_p0 = (((TVMValue*)args)[0].v_handle);
  int32_t arg_p0_code = arg_type_ids[0];
  void* arg_p1 = (((TVMValue*)args)[1].v_handle);
  int32_t arg_p1_code = arg_type_ids[1];
  void* arg_p2 = (((TVMValue*)args)[2].v_handle);
  int32_t arg_p2_code = arg_type_ids[2];
  void* arg_T_relu = (((TVMValue*)args)[3].v_handle);
  int32_t arg_T_relu_code = arg_type_ids[3];
  void* p0 = (((DLTensor*)arg_p0)[0].data);
  void* arg_p0_shape = (((DLTensor*)arg_p0)[0].shape);
  void* arg_p0_strides = (((DLTensor*)arg_p0)[0].strides);
  int32_t dev_id = (((DLTensor*)arg_p0)[0].device.device_id);
  void* p1 = (((DLTensor*)arg_p1)[0].data);
  void* arg_p1_shape = (((DLTensor*)arg_p1)[0].shape);
  void* arg_p1_strides = (((DLTensor*)arg_p1)[0].strides);
  void* p2 = (((DLTensor*)arg_p2)[0].data);
  void* arg_p2_shape = (((DLTensor*)arg_p2)[0].shape);
  void* arg_p2_strides = (((DLTensor*)arg_p2)[0].strides);
  void* T_relu = (((DLTensor*)arg_T_relu)[0].data);
  void* arg_T_relu_shape = (((DLTensor*)arg_T_relu)[0].shape);
  void* arg_T_relu_strides = (((DLTensor*)arg_T_relu)[0].strides);
  if (!(arg_p0_strides == NULL)) {
  }
  if (!(arg_p1_strides == NULL)) {
  }
  if (!(arg_p2_strides == NULL)) {
  }
  if (!(arg_T_relu_strides == NULL)) {
  }
  void* pad_temp = TVMBackendAllocWorkspace(1, dev_id, (uint64_t)2620, 2, 32);
  if (pad_temp == NULL) {
    return -1;
  }
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 131; ++i0_i1_fused) {
    for (int32_t i2 = 0; i2 < 5; ++i2) {
      ((float*)pad_temp)[((i0_i1_fused * 5) + i2)] = (((((1 <= i0_i1_fused) && (i0_i1_fused < 129)) && (1 <= i2)) && (i2 < 4)) ? ((float*)p0)[(((i0_i1_fused * 3) + i2) - 4)] : 0.000000e+00f);
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 384; ++ax0_ax1_fused_ax2_fused) {
    float conv2d_nhwc[1];
    for (int32_t ax3 = 0; ax3 < 8; ++ax3) {
      conv2d_nhwc[0] = 0.000000e+00f;
      for (int32_t ry = 0; ry < 4; ++ry) {
        for (int32_t rx = 0; rx < 3; ++rx) {
          conv2d_nhwc[0] = (conv2d_nhwc[0] + (((float*)pad_temp)[(((((ax0_ax1_fused_ax2_fused / 3) * 5) + (ry * 5)) + rx) + (ax0_ax1_fused_ax2_fused % 3))] * ((float*)p1)[(((ry * 24) + (rx * 8)) + ax3)]));
        }
      }
      float __1 = conv2d_nhwc[0] + ((float*)p2)[ax3];
      ((float*)T_relu)[((ax0_ax1_fused_ax2_fused * 8) + ax3)] = ((__1) > (0.000000e+00f) ? (__1) : (0.000000e+00f));
    }
  }
  if (TVMBackendFreeWorkspace(1, dev_id, pad_temp) != 0) {
    return -1;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_nn_relu_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  void* arg_p0 = (((TVMValue*)args)[0].v_handle);
  int32_t arg_p0_code = arg_type_ids[0];
  void* arg_p1 = (((TVMValue*)args)[1].v_handle);
  int32_t arg_p1_code = arg_type_ids[1];
  void* arg_p2 = (((TVMValue*)args)[2].v_handle);
  int32_t arg_p2_code = arg_type_ids[2];
  void* arg_T_relu = (((TVMValue*)args)[3].v_handle);
  int32_t arg_T_relu_code = arg_type_ids[3];
  void* p0 = (((DLTensor*)arg_p0)[0].data);
  void* arg_p0_shape = (((DLTensor*)arg_p0)[0].shape);
  void* arg_p0_strides = (((DLTensor*)arg_p0)[0].strides);
  int32_t dev_id = (((DLTensor*)arg_p0)[0].device.device_id);
  void* p1 = (((DLTensor*)arg_p1)[0].data);
  void* arg_p1_shape = (((DLTensor*)arg_p1)[0].shape);
  void* arg_p1_strides = (((DLTensor*)arg_p1)[0].strides);
  void* p2 = (((DLTensor*)arg_p2)[0].data);
  void* arg_p2_shape = (((DLTensor*)arg_p2)[0].shape);
  void* arg_p2_strides = (((DLTensor*)arg_p2)[0].strides);
  void* T_relu = (((DLTensor*)arg_T_relu)[0].data);
  void* arg_T_relu_shape = (((DLTensor*)arg_T_relu)[0].shape);
  void* arg_T_relu_strides = (((DLTensor*)arg_T_relu)[0].strides);
  if (!(arg_p0_strides == NULL)) {
  }
  if (!(arg_p1_strides == NULL)) {
  }
  if (!(arg_p2_strides == NULL)) {
  }
  if (!(arg_T_relu_strides == NULL)) {
  }
  void* pad_temp = TVMBackendAllocWorkspace(1, dev_id, (uint64_t)1440, 2, 32);
  if (pad_temp == NULL) {
    return -1;
  }
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 45; ++i0_i1_fused) {
    for (int32_t i3 = 0; i3 < 8; ++i3) {
      int32_t cse_var_1 = ((i0_i1_fused * 8) + i3);
      ((float*)pad_temp)[cse_var_1] = (((1 <= i0_i1_fused) && (i0_i1_fused < 43)) ? ((float*)p0)[(cse_var_1 - 8)] : 0.000000e+00f);
    }
  }
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 42; ++ax0_ax1_fused_ax2_fused) {
    float conv2d_nhwc[1];
    for (int32_t ax3 = 0; ax3 < 16; ++ax3) {
      conv2d_nhwc[0] = 0.000000e+00f;
      for (int32_t ry = 0; ry < 4; ++ry) {
        for (int32_t rc = 0; rc < 8; ++rc) {
          conv2d_nhwc[0] = (conv2d_nhwc[0] + (((float*)pad_temp)[(((ry * 8) + (ax0_ax1_fused_ax2_fused * 8)) + rc)] * ((float*)p1)[(((ry * 128) + (rc * 16)) + ax3)]));
        }
      }
      float __1 = conv2d_nhwc[0] + ((float*)p2)[ax3];
      ((float*)T_relu)[((ax0_ax1_fused_ax2_fused * 16) + ax3)] = ((__1) > (0.000000e+00f) ? (__1) : (0.000000e+00f));
    }
  }
  if (TVMBackendFreeWorkspace(1, dev_id, pad_temp) != 0) {
    return -1;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_dense_add(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  void* arg_p0 = (((TVMValue*)args)[0].v_handle);
  int32_t arg_p0_code = arg_type_ids[0];
  void* arg_p1 = (((TVMValue*)args)[1].v_handle);
  int32_t arg_p1_code = arg_type_ids[1];
  void* arg_p2 = (((TVMValue*)args)[2].v_handle);
  int32_t arg_p2_code = arg_type_ids[2];
  void* arg_T_add = (((TVMValue*)args)[3].v_handle);
  int32_t arg_T_add_code = arg_type_ids[3];
  void* p0 = (((DLTensor*)arg_p0)[0].data);
  void* arg_p0_shape = (((DLTensor*)arg_p0)[0].shape);
  void* arg_p0_strides = (((DLTensor*)arg_p0)[0].strides);
  int32_t dev_id = (((DLTensor*)arg_p0)[0].device.device_id);
  void* p1 = (((DLTensor*)arg_p1)[0].data);
  void* arg_p1_shape = (((DLTensor*)arg_p1)[0].shape);
  void* arg_p1_strides = (((DLTensor*)arg_p1)[0].strides);
  void* p2 = (((DLTensor*)arg_p2)[0].data);
  void* arg_p2_shape = (((DLTensor*)arg_p2)[0].shape);
  void* arg_p2_strides = (((DLTensor*)arg_p2)[0].strides);
  void* T_add = (((DLTensor*)arg_T_add)[0].data);
  void* arg_T_add_shape = (((DLTensor*)arg_T_add)[0].shape);
  void* arg_T_add_strides = (((DLTensor*)arg_T_add)[0].strides);
  if (!(arg_p0_strides == NULL)) {
  }
  if (!(arg_p1_strides == NULL)) {
  }
  if (!(arg_p2_strides == NULL)) {
  }
  if (!(arg_T_add_strides == NULL)) {
  }
  float packed_weight[64];
  float compute_global[4];
  for (int32_t y = 0; y < 16; ++y) {
    for (int32_t x = 0; x < 4; ++x) {
      packed_weight[((y * 4) + x)] = ((float*)p1)[((x * 16) + y)];
    }
  }
  for (int32_t x_c_init = 0; x_c_init < 4; ++x_c_init) {
    compute_global[x_c_init] = 0.000000e+00f;
  }
  for (int32_t k_outer = 0; k_outer < 16; ++k_outer) {
    for (int32_t x_c = 0; x_c < 4; ++x_c) {
      compute_global[x_c] = (compute_global[x_c] + (((float*)p0)[k_outer] * packed_weight[((k_outer * 4) + x_c)]));
    }
  }
  for (int32_t ax1_inner_inner = 0; ax1_inner_inner < 4; ++ax1_inner_inner) {
    ((float*)T_add)[ax1_inner_inner] = (compute_global[ax1_inner_inner] + ((float*)p2)[ax1_inner_inner]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_dense_add_nn_relu(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  void* arg_p0 = (((TVMValue*)args)[0].v_handle);
  int32_t arg_p0_code = arg_type_ids[0];
  void* arg_p1 = (((TVMValue*)args)[1].v_handle);
  int32_t arg_p1_code = arg_type_ids[1];
  void* arg_p2 = (((TVMValue*)args)[2].v_handle);
  int32_t arg_p2_code = arg_type_ids[2];
  void* arg_T_relu = (((TVMValue*)args)[3].v_handle);
  int32_t arg_T_relu_code = arg_type_ids[3];
  void* p0 = (((DLTensor*)arg_p0)[0].data);
  void* arg_p0_shape = (((DLTensor*)arg_p0)[0].shape);
  void* arg_p0_strides = (((DLTensor*)arg_p0)[0].strides);
  int32_t dev_id = (((DLTensor*)arg_p0)[0].device.device_id);
  void* p1 = (((DLTensor*)arg_p1)[0].data);
  void* arg_p1_shape = (((DLTensor*)arg_p1)[0].shape);
  void* arg_p1_strides = (((DLTensor*)arg_p1)[0].strides);
  void* p2 = (((DLTensor*)arg_p2)[0].data);
  void* arg_p2_shape = (((DLTensor*)arg_p2)[0].shape);
  void* arg_p2_strides = (((DLTensor*)arg_p2)[0].strides);
  void* T_relu = (((DLTensor*)arg_T_relu)[0].data);
  void* arg_T_relu_shape = (((DLTensor*)arg_T_relu)[0].shape);
  void* arg_T_relu_strides = (((DLTensor*)arg_T_relu)[0].strides);
  if (!(arg_p0_strides == NULL)) {
  }
  if (!(arg_p1_strides == NULL)) {
  }
  if (!(arg_p2_strides == NULL)) {
  }
  if (!(arg_T_relu_strides == NULL)) {
  }
  void* packed_weight = TVMBackendAllocWorkspace(1, dev_id, (uint64_t)14336, 2, 32);
  if (packed_weight == NULL) {
    return -1;
  }
  for (int32_t z = 0; z < 2; ++z) {
    for (int32_t y = 0; y < 224; ++y) {
      for (int32_t x = 0; x < 8; ++x) {
        int32_t cse_var_1 = (z * 1792);
        ((float*)packed_weight)[((cse_var_1 + (y * 8)) + x)] = ((float*)p1)[((cse_var_1 + (x * 224)) + y)];
      }
    }
  }
  for (int32_t ax1_outer_ax0_outer_fused = 0; ax1_outer_ax0_outer_fused < 2; ++ax1_outer_ax0_outer_fused) {
    float compute_global[8];
    for (int32_t x_c_init = 0; x_c_init < 8; ++x_c_init) {
      compute_global[x_c_init] = 0.000000e+00f;
    }
    for (int32_t k_outer = 0; k_outer < 224; ++k_outer) {
      for (int32_t x_c = 0; x_c < 8; ++x_c) {
        compute_global[x_c] = (compute_global[x_c] + (((float*)p0)[k_outer] * ((float*)packed_weight)[(((ax1_outer_ax0_outer_fused * 1792) + (k_outer * 8)) + x_c)]));
      }
    }
    for (int32_t ax1_inner_inner = 0; ax1_inner_inner < 8; ++ax1_inner_inner) {
      int32_t cse_var_2 = ((ax1_outer_ax0_outer_fused * 8) + ax1_inner_inner);
      float __1 = compute_global[ax1_inner_inner] + ((float*)p2)[cse_var_2];
      ((float*)T_relu)[cse_var_2] = ((__1) > (0.000000e+00f) ? (__1) : (0.000000e+00f));
    }
  }
  if (TVMBackendFreeWorkspace(1, dev_id, packed_weight) != 0) {
    return -1;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_max_pool2d(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  void* arg_p0 = (((TVMValue*)args)[0].v_handle);
  int32_t arg_p0_code = arg_type_ids[0];
  void* arg_pool_max = (((TVMValue*)args)[1].v_handle);
  int32_t arg_pool_max_code = arg_type_ids[1];
  void* p0 = (((DLTensor*)arg_p0)[0].data);
  void* arg_p0_shape = (((DLTensor*)arg_p0)[0].shape);
  void* arg_p0_strides = (((DLTensor*)arg_p0)[0].strides);
  int32_t dev_id = (((DLTensor*)arg_p0)[0].device.device_id);
  void* pool_max = (((DLTensor*)arg_pool_max)[0].data);
  void* arg_pool_max_shape = (((DLTensor*)arg_pool_max)[0].shape);
  void* arg_pool_max_strides = (((DLTensor*)arg_pool_max)[0].strides);
  if (!(arg_p0_strides == NULL)) {
  }
  if (!(arg_pool_max_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 42; ++ax0_ax1_fused) {
    for (int32_t ax3_init = 0; ax3_init < 8; ++ax3_init) {
      ((float*)pool_max)[((ax0_ax1_fused * 8) + ax3_init)] = -3.402823e+38f;
    }
    for (int32_t rv0_rv1_fused = 0; rv0_rv1_fused < 9; ++rv0_rv1_fused) {
      for (int32_t ax3 = 0; ax3 < 8; ++ax3) {
        int32_t cse_var_1 = ((ax0_ax1_fused * 8) + ax3);
        float __1 = ((float*)pool_max)[cse_var_1];
        float __2 = ((float*)p0)[(((ax0_ax1_fused * 72) + (rv0_rv1_fused * 8)) + ax3)];
        ((float*)pool_max)[cse_var_1] = ((__1) > (__2) ? (__1) : (__2));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_max_pool2d_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  void* arg_p0 = (((TVMValue*)args)[0].v_handle);
  int32_t arg_p0_code = arg_type_ids[0];
  void* arg_pool_max = (((TVMValue*)args)[1].v_handle);
  int32_t arg_pool_max_code = arg_type_ids[1];
  void* p0 = (((DLTensor*)arg_p0)[0].data);
  void* arg_p0_shape = (((DLTensor*)arg_p0)[0].shape);
  void* arg_p0_strides = (((DLTensor*)arg_p0)[0].strides);
  int32_t dev_id = (((DLTensor*)arg_p0)[0].device.device_id);
  void* pool_max = (((DLTensor*)arg_pool_max)[0].data);
  void* arg_pool_max_shape = (((DLTensor*)arg_pool_max)[0].shape);
  void* arg_pool_max_strides = (((DLTensor*)arg_pool_max)[0].strides);
  if (!(arg_p0_strides == NULL)) {
  }
  if (!(arg_pool_max_strides == NULL)) {
  }
  for (int32_t ax0_ax1_fused = 0; ax0_ax1_fused < 14; ++ax0_ax1_fused) {
    for (int32_t ax3_init = 0; ax3_init < 16; ++ax3_init) {
      ((float*)pool_max)[((ax0_ax1_fused * 16) + ax3_init)] = -3.402823e+38f;
    }
    for (int32_t rv0_rv1_fused = 0; rv0_rv1_fused < 3; ++rv0_rv1_fused) {
      for (int32_t ax3 = 0; ax3 < 16; ++ax3) {
        int32_t cse_var_1 = ((ax0_ax1_fused * 16) + ax3);
        float __1 = ((float*)pool_max)[cse_var_1];
        float __2 = ((float*)p0)[(((ax0_ax1_fused * 48) + (rv0_rv1_fused * 16)) + ax3)];
        ((float*)pool_max)[cse_var_1] = ((__1) > (__2) ? (__1) : (__2));
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_softmax(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  void* arg_p0 = (((TVMValue*)args)[0].v_handle);
  int32_t arg_p0_code = arg_type_ids[0];
  void* arg_T_softmax_norm = (((TVMValue*)args)[1].v_handle);
  int32_t arg_T_softmax_norm_code = arg_type_ids[1];
  void* p0 = (((DLTensor*)arg_p0)[0].data);
  void* arg_p0_shape = (((DLTensor*)arg_p0)[0].shape);
  void* arg_p0_strides = (((DLTensor*)arg_p0)[0].strides);
  int32_t dev_id = (((DLTensor*)arg_p0)[0].device.device_id);
  void* T_softmax_norm = (((DLTensor*)arg_T_softmax_norm)[0].data);
  void* arg_T_softmax_norm_shape = (((DLTensor*)arg_T_softmax_norm)[0].shape);
  void* arg_T_softmax_norm_strides = (((DLTensor*)arg_T_softmax_norm)[0].strides);
  if (!(arg_p0_strides == NULL)) {
  }
  if (!(arg_T_softmax_norm_strides == NULL)) {
  }
  float T_softmax_maxelem[1];
  float T_softmax_exp[4];
  float T_softmax_expsum[1];
  T_softmax_maxelem[0] = -3.402823e+38f;
  for (int32_t k = 0; k < 4; ++k) {
    float __1 = T_softmax_maxelem[0];
    float __2 = ((float*)p0)[k];
    T_softmax_maxelem[0] = ((__1) > (__2) ? (__1) : (__2));
  }
  for (int32_t i1 = 0; i1 < 4; ++i1) {
    T_softmax_exp[i1] = expf((((float*)p0)[i1] - T_softmax_maxelem[0]));
  }
  T_softmax_expsum[0] = 0.000000e+00f;
  for (int32_t k_1 = 0; k_1 < 4; ++k_1) {
    T_softmax_expsum[0] = (T_softmax_expsum[0] + T_softmax_exp[k_1]);
  }
  for (int32_t i1_1 = 0; i1_1 < 4; ++i1_1) {
    ((float*)T_softmax_norm)[i1_1] = (T_softmax_exp[i1_1] / T_softmax_expsum[0]);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_reshape(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  void* arg_p0 = (((TVMValue*)args)[0].v_handle);
  int32_t arg_p0_code = arg_type_ids[0];
  void* arg_T_reshape = (((TVMValue*)args)[1].v_handle);
  int32_t arg_T_reshape_code = arg_type_ids[1];
  void* p0 = (((DLTensor*)arg_p0)[0].data);
  void* arg_p0_shape = (((DLTensor*)arg_p0)[0].shape);
  void* arg_p0_strides = (((DLTensor*)arg_p0)[0].strides);
  int32_t dev_id = (((DLTensor*)arg_p0)[0].device.device_id);
  void* T_reshape = (((DLTensor*)arg_T_reshape)[0].data);
  void* arg_T_reshape_shape = (((DLTensor*)arg_T_reshape)[0].shape);
  void* arg_T_reshape_strides = (((DLTensor*)arg_T_reshape)[0].strides);
  if (!(arg_p0_strides == NULL)) {
  }
  if (!(arg_T_reshape_strides == NULL)) {
  }
  for (int32_t ax1_outer = 0; ax1_outer < 14; ++ax1_outer) {
    for (int32_t ax1_inner = 0; ax1_inner < 16; ++ax1_inner) {
      int32_t cse_var_1 = ((ax1_outer * 16) + ax1_inner);
      ((float*)T_reshape)[cse_var_1] = ((float*)p0)[cse_var_1];
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_reshape_1(void* args, int32_t* arg_type_ids, int32_t num_args, void* out_ret_value, int32_t* out_ret_tcode, void* resource_handle) {
  void* arg_p0 = (((TVMValue*)args)[0].v_handle);
  int32_t arg_p0_code = arg_type_ids[0];
  void* arg_T_reshape = (((TVMValue*)args)[1].v_handle);
  int32_t arg_T_reshape_code = arg_type_ids[1];
  void* p0 = (((DLTensor*)arg_p0)[0].data);
  void* arg_p0_shape = (((DLTensor*)arg_p0)[0].shape);
  void* arg_p0_strides = (((DLTensor*)arg_p0)[0].strides);
  int32_t dev_id = (((DLTensor*)arg_p0)[0].device.device_id);
  void* T_reshape = (((DLTensor*)arg_T_reshape)[0].data);
  void* arg_T_reshape_shape = (((DLTensor*)arg_T_reshape)[0].shape);
  void* arg_T_reshape_strides = (((DLTensor*)arg_T_reshape)[0].strides);
  if (!(arg_p0_strides == NULL)) {
  }
  if (!(arg_T_reshape_strides == NULL)) {
  }
  for (int32_t ax1_inner = 0; ax1_inner < 16; ++ax1_inner) {
    ((float*)T_reshape)[ax1_inner] = ((float*)p0)[ax1_inner];
  }
  return 0;
}

